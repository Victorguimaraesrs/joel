// Landing Page JavaScript - Joel Vargas
document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize page animations
    initializeAnimations();
    
    // Setup social media button interactions
    setupSocialButtons();
    
    // Create dynamic background effects
    createBackgroundEffects();
    
    // Setup profile image placeholder
    setupProfileImage();
    
});

function initializeAnimations() {
    // Animate elements on page load
    const mainContent = document.querySelector('.main-content');
    const title = document.querySelector('.main-title');
    const profilePhoto = document.querySelector('.profile-photo');
    const description = document.querySelector('.description-container');
    const socialButtons = document.querySelectorAll('.social-button');
    
    // Set initial states
    mainContent.style.opacity = '0';
    mainContent.style.transform = 'translateY(30px)';
    
    // Animate main content
    setTimeout(() => {
        mainContent.style.transition = 'all 1s ease-out';
        mainContent.style.opacity = '1';
        mainContent.style.transform = 'translateY(0)';
    }, 100);
    
    // Animate title with delay
    setTimeout(() => {
        title.style.animation = 'titleGlow 3s ease-in-out infinite, fadeInUp 1s ease-out';
    }, 300);
    
    // Animate profile photo
    setTimeout(() => {
        profilePhoto.style.animation = 'photoFloat 4s ease-in-out infinite, fadeInScale 1s ease-out';
    }, 600);
    
    // Animate description
    setTimeout(() => {
        description.style.animation = 'fadeInUp 1s ease-out';
    }, 900);
    
    // Animate social buttons with stagger
    socialButtons.forEach((button, index) => {
        setTimeout(() => {
            button.style.animation = 'fadeInUp 0.8s ease-out';
        }, 1200 + (index * 150));
    });
}

function setupSocialButtons() {
    const socialButtons = document.querySelectorAll('.social-button');
    
    socialButtons.forEach(button => {
        // Add click animation
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Create ripple effect
            createRippleEffect(this, e);
            
            // Get platform
            const platform = this.dataset.platform;
            
            // Show placeholder message (since URLs will be added later)
            showLinkMessage(platform);
        });
        
        // Add hover sound effect (visual feedback)
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.02)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
}

function createRippleEffect(button, event) {
    const ripple = document.createElement('div');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s ease-out;
        pointer-events: none;
        z-index: 1;
    `;
    
    button.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

function showLinkMessage(platform) {
    // Create temporary message
    const message = document.createElement('div');
    message.textContent = `Link do ${platform} será adicionado em breve!`;
    message.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 255, 136, 0.9);
        color: #000;
        padding: 15px 25px;
        border-radius: 10px;
        font-weight: 600;
        z-index: 1000;
        animation: fadeInOut 2s ease-in-out;
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.remove();
    }, 2000);
}

function createBackgroundEffects() {
    // Create floating particles
    const particlesContainer = document.querySelector('.floating-particles');
    
    for (let i = 0; i < 20; i++) {
        createFloatingParticle(particlesContainer);
    }
    
    // Create dynamic grid animation
    animateGrid();
}

function createFloatingParticle(container) {
    const particle = document.createElement('div');
    const size = Math.random() * 4 + 2;
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    const duration = Math.random() * 10 + 10;
    
    particle.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}%;
        top: ${y}%;
        background: radial-gradient(circle, rgba(0, 255, 136, 0.8) 0%, transparent 70%);
        border-radius: 50%;
        animation: floatParticle ${duration}s ease-in-out infinite;
        pointer-events: none;
    `;
    
    container.appendChild(particle);
}

function animateGrid() {
    const grid = document.querySelector('.neon-grid');
    let intensity = 0.1;
    let direction = 1;
    
    setInterval(() => {
        intensity += direction * 0.02;
        if (intensity >= 0.3 || intensity <= 0.1) {
            direction *= -1;
        }
        
        grid.style.backgroundImage = `
            linear-gradient(rgba(0, 255, 136, ${intensity}) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 136, ${intensity}) 1px, transparent 1px)
        `;
    }, 100);
}

function setupProfileImage() {
    const profileImg = document.getElementById('profileImage');
    
    // Set placeholder image with green theme
    profileImg.src = 'data:image/svg+xml;base64,' + btoa(`
        <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#00ff88;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#00cc6a;stop-opacity:1" />
                </linearGradient>
            </defs>
            <circle cx="100" cy="100" r="100" fill="url(#grad)" />
            <circle cx="100" cy="80" r="30" fill="rgba(255,255,255,0.3)" />
            <path d="M 60 140 Q 100 120 140 140 Q 140 160 100 160 Q 60 160 60 140" fill="rgba(255,255,255,0.3)" />
            <text x="100" y="180" text-anchor="middle" fill="white" font-family="Arial" font-size="12">Joel Vargas</text>
        </svg>
    `);
    
    // Add error handling
    profileImg.onerror = function() {
        this.src = 'data:image/svg+xml;base64,' + btoa(`
            <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
                <circle cx="100" cy="100" r="100" fill="#00ff88" />
                <text x="100" y="110" text-anchor="middle" fill="white" font-family="Arial" font-size="24" font-weight="bold">JV</text>
            </svg>
        `);
    };
}

// Add CSS animations dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes fadeInScale {
        from {
            opacity: 0;
            transform: scale(0.8);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    @keyframes fadeInOut {
        0%, 100% { opacity: 0; }
        20%, 80% { opacity: 1; }
    }
    
    @keyframes floatParticle {
        0%, 100% {
            transform: translateY(0px) translateX(0px);
            opacity: 0.3;
        }
        25% {
            transform: translateY(-20px) translateX(10px);
            opacity: 0.8;
        }
        50% {
            transform: translateY(-10px) translateX(-5px);
            opacity: 0.5;
        }
        75% {
            transform: translateY(-30px) translateX(15px);
            opacity: 0.9;
        }
    }
`;

document.head.appendChild(style);

// Smooth scrolling for any future navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add keyboard navigation support
document.addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
    }
});

document.addEventListener('mousedown', function() {
    document.body.classList.remove('keyboard-navigation');
});

// Performance optimization: Reduce animations on low-end devices
if (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) {
    document.body.classList.add('reduced-motion');
    
    const reducedMotionStyle = document.createElement('style');
    reducedMotionStyle.textContent = `
        .reduced-motion * {
            animation-duration: 0.5s !important;
            transition-duration: 0.2s !important;
        }
    `;
    document.head.appendChild(reducedMotionStyle);
}

