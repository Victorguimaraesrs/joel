# Instruções para Exportação Elementor

## Sobre a Landing Page
Esta landing page foi desenvolvida em HTML/CSS/JavaScript puro e pode ser adaptada para o Elementor seguindo as instruções abaixo.

## Conversão para Elementor

### 1. Estrutura da Página
- **Container Principal**: Seção full-width com background gradient verde
- **Header**: Widget de título com fonte Orbitron
- **Foto de Perfil**: Widget de imagem circular
- **Descrição**: Widget de texto com background translúcido
- **Botões Sociais**: Widgets de botão com ícones personalizados

### 2. Configurações de Design

#### Background da Página
```
Tipo: Gradient
Cor 1: #0a1a0a
Cor 2: #1a3d2e
Cor 3: #0d2818
Direção: 135deg
```

#### Tipografia
- **Título Principal**: Orbitron, 900, 5rem (desktop), 3rem (mobile)
- **Descrição**: Poppins, 400, 16px
- **Botões**: Poppins, 600, 18px

#### Cores
- **Verde Primário**: #00ff88
- **Verde Neon**: #39ff14
- **Verde Escuro**: #0d4f3c
- **Texto**: #ffffff

### 3. Elementos Personalizados

#### Grid Neon (Background)
- Adicionar via CSS personalizado:
```css
background-image: 
    linear-gradient(rgba(0, 255, 136, 0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0, 255, 136, 0.1) 1px, transparent 1px);
background-size: 50px 50px;
```

#### Foto de Perfil
- Widget: Image
- Border-radius: 50%
- Border: 3px solid #00ff88
- Box-shadow: 0 0 30px rgba(0, 255, 136, 0.6)

#### Botões Sociais
- Widget: Button
- Border-radius: 30px
- Background: linear-gradient(135deg, rgba(0, 255, 136, 0.1), rgba(0, 204, 106, 0.1))
- Border: 2px solid rgba(0, 255, 136, 0.3)
- Hover: Transform translateY(-3px)

### 4. Animações

#### CSS Personalizado para Animações
```css
@keyframes titleGlow {
    0%, 100% { text-shadow: 0 0 30px rgba(0, 255, 136, 0.5); }
    50% { text-shadow: 0 0 50px rgba(0, 255, 136, 0.8); }
}

@keyframes photoFloat {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
}
```

### 5. Responsividade

#### Breakpoints
- **Desktop**: > 1024px
- **Tablet**: 768px - 1024px
- **Mobile**: < 768px

#### Ajustes Mobile
- Título: 3rem
- Foto: 150x150px
- Padding: 15px
- Botões: altura 50px

### 6. Exportação JSON

Para criar o template JSON do Elementor:

1. **Criar nova página no Elementor**
2. **Adicionar seções conforme estrutura**
3. **Aplicar estilos personalizados**
4. **Testar responsividade**
5. **Exportar como template**

### 7. Código CSS Adicional

Adicione este CSS na seção "CSS Personalizado" do Elementor:

```css
/* Efeitos futuristas */
.elementor-widget-heading h1 {
    background: linear-gradient(45deg, #00ff88, #39ff14, #00cc6a);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: titleGlow 3s ease-in-out infinite;
}

.elementor-widget-image img {
    animation: photoFloat 4s ease-in-out infinite;
}

.elementor-widget-button .elementor-button {
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
}

.elementor-widget-button .elementor-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0, 255, 136, 0.3);
}
```

### 8. Ícones das Redes Sociais

Use os seguintes códigos SVG para os ícones:

- **Instagram**: Disponível na biblioteca do Elementor
- **WhatsApp**: Disponível na biblioteca do Elementor  
- **TikTok**: Disponível na biblioteca do Elementor
- **Facebook**: Disponível na biblioteca do Elementor

### 9. Nome do Arquivo de Exportação
`central_links_joel_vargas.json`

### 10. Observações Importantes
- Teste sempre em diferentes dispositivos
- Verifique a velocidade de carregamento
- Mantenha a acessibilidade
- Use imagens otimizadas
- Configure meta tags adequadas

---

**Esta estrutura garante que o design futurista seja mantido no Elementor com todas as funcionalidades originais.**

