# Landing Page - Joel Vargas

## Descrição
Landing page (central de links) criada para Joel Vargas com design futurista e contemporâneo, utilizando cores verdes vibrantes conforme especificado.

## Características

### Design
- **Estilo**: Futurista e contemporâneo
- **Cores**: Verde vibrante (#00FF88), verde neon (#39FF14), verde escuro (#0D4F3C)
- **Tipografia**: Orbitron (título) e Poppins (corpo)
- **Efeitos**: Animações suaves, gradientes, sombras com glow verde

### Funcionalidades
- **Responsivo**: Adaptação completa para dispositivos móveis
- **Interativo**: Efeitos hover nos botões, animações de entrada
- **Acessível**: Navegação por teclado, contraste adequado
- **Performance**: Otimizado para carregamento rápido

### Estrutura
1. **Cabeçalho**: Nome "Joel Vargas" com fonte Orbitron e efeito glow
2. **Foto de Perfil**: Circular (200x200px) com placeholder SVG
3. **Descrição**: Biografia completa de Joel Vargas
4. **Botões Sociais**: Instagram, WhatsApp, TikTok, Facebook

## Arquivos

### `index.html`
Estrutura HTML5 semântica com:
- Meta tags para responsividade
- Links para Google Fonts (Orbitron e Poppins)
- Ícones SVG das redes sociais
- Estrutura acessível

### `styles.css`
CSS3 avançado com:
- Variáveis CSS para cores
- Flexbox e Grid Layout
- Animações e transições
- Media queries para responsividade
- Efeitos visuais (gradientes, sombras, glow)

### `script.js`
JavaScript moderno com:
- Animações de entrada
- Efeitos de interação
- Partículas flutuantes
- Otimizações de performance
- Suporte a teclado

## Personalização

### Adicionando Foto de Perfil
Substitua o arquivo `profile-placeholder.jpg` por uma foto real de Joel Vargas (200x200px recomendado).

### Adicionando Links das Redes Sociais
Edite o arquivo `script.js` e substitua os links placeholder:

```javascript
// Exemplo para Instagram
document.querySelector('.social-button.instagram').href = 'https://instagram.com/joelvargas';
```

### Cores Personalizadas
Modifique as variáveis CSS no arquivo `styles.css`:

```css
:root {
    --primary-green: #00ff88;
    --neon-green: #39ff14;
    --dark-green: #0d4f3c;
}
```

## Compatibilidade
- **Navegadores**: Chrome 60+, Firefox 55+, Safari 12+, Edge 79+
- **Dispositivos**: Desktop, tablet, smartphone
- **Resolução**: 320px a 4K

## Tecnologias Utilizadas
- HTML5
- CSS3 (Flexbox, Grid, Animations)
- JavaScript ES6+
- Google Fonts
- SVG Icons

## Instalação
1. Faça download de todos os arquivos
2. Abra `index.html` em um navegador
3. Para desenvolvimento local, use um servidor HTTP

## Suporte
Para dúvidas ou modificações, consulte os comentários no código ou entre em contato com o desenvolvedor.

---

**Desenvolvido com foco em design futurista e experiência do usuário moderna.**

